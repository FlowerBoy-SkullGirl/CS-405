// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

const unsigned int MAX_USER_INPUT = 20;

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // Use a string class object as the input buffer so that overflow is checked and managed by the class implementation
  // Reallocation occurs if buffer size is not large enough to hold input
  // Define a global "MAX_USER_INPUT" to determine if the user has entered too many characters before continuing process execution
  // string will also be on the heap rather than the stack, so stack smashing should not be possible on most implementations
  const std::string account_number = "CharlieBrown42";
  std::string user_input;
  std::cout << "Enter a value: ";
  std::cin >> user_input;

  // Make the output more visually pleasing
  std::cout << std::endl;

  // std::string does not contain a null terminator, so to preserve the logic of the
  // original char array, we subtract 1 from the max input size before comparison
  if (user_input.length() >= (MAX_USER_INPUT - 1)){
	  std::cout << "You entered too many characters!" << std::endl;
	  return 1;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;

  //string object uses destructor to free memory that was allocated, no further calls required
  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
