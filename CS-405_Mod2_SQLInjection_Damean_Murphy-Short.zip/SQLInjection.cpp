// SQLInjection.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <algorithm>
#include <iostream>
#include <locale>
#include <tuple>
#include <vector>

#include "sqlite3.h"

// DO NOT CHANGE
typedef std::tuple<std::string, std::string, std::string> user_record;
const std::string str_where = " where ";

// DO NOT CHANGE
static int callback(void* possible_vector, int argc, char** argv, char** azColName)
{
  if (possible_vector == NULL)
  { // no vector passed in, so just display the results
    for (int i = 0; i < argc; i++) 
    {
      std::cout << azColName[i] << " = " << (argv[i] ? argv[i] : "NULL") << std::endl;
    }
    std::cout << std::endl;
  }
  else
  {
    std::vector< user_record >* rows =
      static_cast<std::vector< user_record > *>(possible_vector);

    rows->push_back(std::make_tuple(argv[0], argv[1], argv[2]));
  }
  return 0;
}

// DO NOT CHANGE
bool initialize_database(sqlite3* db)
{
  char* error_message = NULL;
  std::string sql = "CREATE TABLE USERS(" \
    "ID INT PRIMARY KEY     NOT NULL," \
    "NAME           TEXT    NOT NULL," \
    "PASSWORD       TEXT    NOT NULL);";

  int result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
  if (result != SQLITE_OK)
  {
    std::cout << "Failed to create USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }
  std::cout << "USERS table created." << std::endl;

  // insert some dummy data
  sql = "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (1, 'Fred', 'Flinstone');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (2, 'Barney', 'Rubble');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (3, 'Wilma', 'Flinstone');" \
    "INSERT INTO USERS (ID, NAME, PASSWORD)" \
    "VALUES (4, 'Betty', 'Rubble');";

  result = sqlite3_exec(db, sql.c_str(), callback, NULL, &error_message);
  if (result != SQLITE_OK)
  {
    std::cout << "Data failed to insert to USERS table. ERROR = " << error_message << std::endl;
    sqlite3_free(error_message);
    return false;
  }

  return true;
}

// Checks for common injection characters to avoid a subset of SQL injection attacks
// Should be used on any sql string that contains user input
bool validate_sql(const std::string& sql)
{
	// Assume all queries with escape characters are malicious, for the given use-case of run_query of accepting strings that contain user input
	if (sql.find('\\') != std::string::npos)
		return false;
	// Assume all queries with comments are likewise malicious
	if (sql.find("--") != std::string::npos)
		return false;

	// User-input strings should not contain sql keywords that may influence the query logic
	if ((sql.find(" OR ") != std::string::npos) || (sql.find(" or ") != std::string::npos))
		return false;

	// If all tests are satisfied, return true
	return true;
}

#ifdef REMOVE_FROM_PRODUCTION
bool run_query(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  const int EXPECTED_COL = 3;
  char* error_message;
  std::string sql_name_query = "WHERE NAME=";
  std::string sql_parameter_val;

  // clear any prior results
  records.clear();

  // User input and input directly from application code should be run against different logic
  // Statements like "SELECT * FROM USERS" should not normally be allowed, but we make an exception
  // To this specific string during this specific test
  if (sql.compare("SELECT * from USERS") == 0){
  	if(sqlite3_exec(db, sql.c_str(), callback, &records, &error_message) != SQLITE_OK)
	  {
	    std::cout << "Data failed to be queried from USERS table. ERROR = " << error_message << std::endl;
	    sqlite3_free(error_message);
	    return false;
	  }
	return true;
  }

  // Perform validation here before call to sqlite3
  if (validate_sql(sql) == false){
	std::cout << "Query is invalid, please contact database administrator" << std::endl;
	return false;
  }
  // Parameterized queries ensure that SQL logic from the user is not executed and only prepared statements are run
  // i.e. statements expected by the application
  sqlite3_stmt* stmt;

  // Our only allowed query for user input to influence are queries of "WHERE NAME = ?"
  // If we were to allow more queries, we could add more parameterized query statements to select from
  size_t parameter_index = 0;
  if ((parameter_index = sql.find(sql_name_query)) != std::string::npos){
	std::string parameterized_sql = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME=?1;";
	
	// Set size to -1 since the c_str() is guaranteed to produce a null terminated string
	if (sqlite3_prepare_v2(db, parameterized_sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK){
		std::cout << "Could not build query, please contact database administrator" << std::endl;
		return false;
	}
	// Move the parameter index exactly the length 1 past the "WHERE NAME=" substr
	parameter_index += sql_name_query.size();

	// Substr will throw exception if our parameter index is out of bounds
	try{
		// Passing npos causes substr to return from index to end of string
		sql_parameter_val = sql.substr(parameter_index, std::string::npos);
		// Clean the value of quotes
		size_t quote_i = std::string::npos;
		while ((quote_i = sql_parameter_val.find('\'')) != std::string::npos){
			sql_parameter_val.erase(quote_i, 1);
		}
		while ((quote_i = sql_parameter_val.find('\"')) != std::string::npos){
			sql_parameter_val.erase(quote_i, 1);
		}
	}catch (const std::out_of_range& ex){
		std::cout << "Could not build query, please contact database administrator" << std::endl;
		sqlite3_finalize(stmt);
		return false;
	}

	// Bind the parameter to the parameterized sql statement
	// SQLITE_STATIC indicates memory management to be used
	// Set size to -1 since the c_str() is guaranteed to produce a null terminated string
	if (sqlite3_bind_text(stmt, 1, sql_parameter_val.c_str(), -1, SQLITE_STATIC) != SQLITE_OK){
		std::cout << "Could not build query, please contact database administrator" << std::endl;
		sqlite3_finalize(stmt);
		return false;
	}
	// Debug:
	//std::cout << sqlite3_expanded_sql(stmt) << std::endl;
	if (sqlite3_reset(stmt) != SQLITE_OK){
			return false;
	}

	// sqlite3_step returns SQLITE_DONE when no rows are found by SELECT query
	int result = SQLITE_OK;
	while((result = sqlite3_step(stmt)) != SQLITE_DONE){
		switch(result){
			case SQLITE_MISUSE:
				std::cout << "Error during query, please contact database administrator" << std::endl;
				sqlite3_finalize(stmt);
				return false;
				break;
			case SQLITE_ERROR:
				std::cout << "Error during query, please contact database administrator" << std::endl;
				sqlite3_finalize(stmt);
				return false;
				break;
			// Data is returned
			case SQLITE_ROW:
				// Error if the expected amount of data is not returned
				if (sqlite3_column_count(stmt) < EXPECTED_COL){
					std::cout << "Error during query, please contact database administrator" << std::endl;
					sqlite3_finalize(stmt);
					return false;
				}
				// Brackets to specify scope of variables to compiler
				// Cast the column_text to const char *, assign value to strings, add strings to record, and push
				// record onto records vector
				{
				std::string col0 = (const char *) sqlite3_column_text(stmt, 0);
				std::string col1 = (const char *) sqlite3_column_text(stmt, 1);
				std::string col2 = (const char *) sqlite3_column_text(stmt, 2);
				user_record rec(col0, col1, col2);

				records.push_back(rec);
				}

				break;
			default:
				// Repeat step if DB is busy or some other result is returned
				break;
		}
	}
	// Cleanup the parameterized statement
	sqlite3_finalize(stmt);
  }

  return true;
}
#endif

#ifndef REMOVE_FROM_PRODUCTION
//Put run_query() function without test exceptions here
bool run_query(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  const int EXPECTED_COL = 3;
  char* error_message;
  std::string sql_name_query = "WHERE NAME=";
  std::string sql_parameter_val;

  // clear any prior results
  records.clear();

  // Perform validation here before call to sqlite3
  if (validate_sql(sql) == false){
	std::cout << "Query is invalid, please contact database administrator" << std::endl;
	return false;
  }
  // Parameterized queries ensure that SQL logic from the user is not executed and only prepared statements are run
  // i.e. statements expected by the application
  sqlite3_stmt* stmt;

  // Our only allowed query for user input to influence are queries of "WHERE NAME = ?"
  // If we were to allow more queries, we could add more parameterized query statements to select from
  size_t parameter_index = 0;
  if ((parameter_index = sql.find(sql_name_query)) != std::string::npos){
	std::string parameterized_sql = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME=?1;";
	
	// Set size to -1 since the c_str() is guaranteed to produce a null terminated string
	if (sqlite3_prepare_v2(db, parameterized_sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK){
		std::cout << "Could not build query, please contact database administrator" << std::endl;
		return false;
	}
	// Move the parameter index exactly the length 1 past the "WHERE NAME=" substr
	parameter_index += sql_name_query.size();

	// Substr will throw exception if our parameter index is out of bounds
	try{
		// Passing npos causes substr to return from index to end of string
		sql_parameter_val = sql.substr(parameter_index, std::string::npos);
		// Clean the value of quotes
		size_t quote_i = std::string::npos;
		while ((quote_i = sql_parameter_val.find('\'')) != std::string::npos){
			sql_parameter_val.erase(quote_i, 1);
		}
		while ((quote_i = sql_parameter_val.find('\"')) != std::string::npos){
			sql_parameter_val.erase(quote_i, 1);
		}
	}catch (const std::out_of_range& ex){
		std::cout << "Could not build query, please contact database administrator" << std::endl;
		sqlite3_finalize(stmt);
		return false;
	}

	// Bind the parameter to the parameterized sql statement
	// SQLITE_STATIC indicates memory management to be used
	// Set size to -1 since the c_str() is guaranteed to produce a null terminated string
	if (sqlite3_bind_text(stmt, 1, sql_parameter_val.c_str(), -1, SQLITE_STATIC) != SQLITE_OK){
		std::cout << "Could not build query, please contact database administrator" << std::endl;
		sqlite3_finalize(stmt);
		return false;
	}
	// Debug:
	//std::cout << sqlite3_expanded_sql(stmt) << std::endl;
	if (sqlite3_reset(stmt) != SQLITE_OK){
			return false;
	}

	// sqlite3_step returns SQLITE_DONE when no rows are found by SELECT query
	int result = SQLITE_OK;
	while((result = sqlite3_step(stmt)) != SQLITE_DONE){
		switch(result){
			case SQLITE_MISUSE:
				std::cout << "Error during query, please contact database administrator" << std::endl;
				sqlite3_finalize(stmt);
				return false;
				break;
			case SQLITE_ERROR:
				std::cout << "Error during query, please contact database administrator" << std::endl;
				sqlite3_finalize(stmt);
				return false;
				break;
			// Data is returned
			case SQLITE_ROW:
				// Error if the expected amount of data is not returned
				if (sqlite3_column_count(stmt) < EXPECTED_COL){
					std::cout << "Error during query, please contact database administrator" << std::endl;
					sqlite3_finalize(stmt);
					return false;
				}
				// Brackets to specify scope of variables to compiler
				// Cast the column_text to const char *, assign value to strings, add strings to record, and push
				// record onto records vector
				{
				std::string col0 = (const char *) sqlite3_column_text(stmt, 0);
				std::string col1 = (const char *) sqlite3_column_text(stmt, 1);
				std::string col2 = (const char *) sqlite3_column_text(stmt, 2);
				user_record rec(col0, col1, col2);

				records.push_back(rec);
				}

				break;
			default:
				// Repeat step if DB is busy or some other result is returned
				break;
		}
	}
	// Cleanup the parameterized statement
	sqlite3_finalize(stmt);
  }

  return true;
}
#endif

// DO NOT CHANGE
bool run_query_injection(sqlite3* db, const std::string& sql, std::vector< user_record >& records)
{
  std::string injectedSQL(sql);
  std::string localCopy(sql);

  // we work on the local copy because of the const
  std::transform(localCopy.begin(), localCopy.end(), localCopy.begin(), ::tolower);
  if(localCopy.find_last_of(str_where) >= 0)
  { // this sql has a where clause
    if(localCopy.back() == ';')
    { // smart SQL developer terminated with a semicolon - we can fix that!
      injectedSQL.pop_back();
    }

    switch (rand() % 4)
    {
    case 1:
      injectedSQL.append(" or 2=2;");
      break;
    case 2:
      injectedSQL.append(" or 'hi'='hi';");
      break;
    case 3:
      injectedSQL.append(" or 'hack'='hack';");
      break;
    case 0:
    default:
      injectedSQL.append(" or 1=1;");
      break;
    }
  }
  
  return run_query(db, injectedSQL, records);
}


// DO NOT CHANGE
void dump_results(const std::string& sql, const std::vector< user_record >& records)
{
  std::cout << std::endl << "SQL: " << sql << " ==> " << records.size() << " records found." << std::endl;

  for (auto record : records)
  {
    std::cout << "User: " << std::get<1>(record) << " [UID=" << std::get<0>(record) << " PWD=" << std::get<2>(record) << "]" << std::endl;
  }
}

// DO NOT CHANGE
void run_queries(sqlite3* db)
{
  char* error_message = NULL;

  std::vector< user_record > records;

  // query all
  std::string sql = "SELECT * from USERS";
  if (!run_query(db, sql, records)) return;
  dump_results(sql, records);

  //  query 1
  sql = "SELECT ID, NAME, PASSWORD FROM USERS WHERE NAME='Fred'";
  if (!run_query(db, sql, records)) return;
  dump_results(sql, records);

  //  run query 1 with injection 5 times
  for (auto i = 0; i < 5; ++i)
  {
    if (!run_query_injection(db, sql, records)) continue;
    dump_results(sql, records);
  }

}

// You can change main by adding stuff to it, but all of the existing code must remain, and be in the
// in the order called, and with none of this existing code placed into conditional statements
int main()
{
  // initialize random seed:
  srand(time(nullptr));

  int return_code = 0;
  std::cout << "SQL Injection Example" << std::endl;

  // the database handle
  sqlite3* db = NULL;
  char* error_message = NULL;

  // open the database connection
  int result = sqlite3_open(":memory:", &db);

  if(result != SQLITE_OK)
  {
    std::cout << "Failed to connect to the database and terminating. ERROR=" << sqlite3_errmsg(db) << std::endl;
    return -1;
  }

  std::cout << "Connected to the database." << std::endl;

  // initialize our database
  if(!initialize_database(db))
  {
    std::cout << "Database Initialization Failed. Terminating." << std::endl;
    return_code = -1;
  }
  else
  {
    run_queries(db);
  }

  // close the connection if opened
  if(db != NULL)
  {
    sqlite3_close(db);
  }

  return return_code;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
