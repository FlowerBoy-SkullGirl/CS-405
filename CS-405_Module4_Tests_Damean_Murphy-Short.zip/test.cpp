// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}

// Verifies if a single value can be added to the collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  const int test_val = 1;
  // is the collection empty?
  // if empty, the size must be 0
  ASSERT_TRUE(collection->empty());

  add_entries(test_val);

  // is the collection still empty?
  // if not empty, what must the size be?
  ASSERT_FALSE(collection->empty());
  ASSERT_EQ(collection->size(), test_val);
}

// Verifies if 5 values can be added to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  const int test_val = 5;
  // is the collection empty?
  // if empty, the size must be 0
  ASSERT_TRUE(collection->empty());

  add_entries(test_val);

  // is the collection still empty?
  // if not empty, what must the size be?
  ASSERT_FALSE(collection->empty());
  ASSERT_EQ(collection->size(), test_val);
}

// Verifies that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, EnsureMaxSizeGreaterThanSize)
{
	const unsigned int num_test_vals = 4;
	const int test_vals[num_test_vals] = {0, 1, 5, 10};

	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Loop through the multiple test values
	for (unsigned int i = 0; i < num_test_vals; i++)
	{
		// Resize collection to test value
		collection->resize(test_vals[i]);

		// Is the collection now equal to the test_val size
		ASSERT_EQ(collection->size(), test_vals[i]);

		// Is the capacity greater or equal to the size (EXPECT so that subsequent values can be tested)
		EXPECT_TRUE(collection->max_size() >= collection->size());
	}
}

// Verifies that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, EnsureCapacityGreaterThanSize)
{
	const unsigned int num_test_vals = 4;
	const int test_vals[num_test_vals] = {0, 1, 5, 10};

	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Loop through the multiple test values
	for (unsigned int i = 0; i < num_test_vals; i++)
	{
		// Resize collection to test value
		collection->resize(test_vals[i]);

		// Is the collection now equal to the test_val size
		ASSERT_EQ(collection->size(), test_vals[i]);

		// Is the capacity greater or equal to the size (EXPECT so that subsequent values can be tested)
		EXPECT_TRUE(collection->capacity() >= collection->size());
	}
}

// Verifies resizing increases the collection
TEST_F(CollectionTest, EnsureResizeIncreasesSize)
{
	const int test_val = 10;
	const int resize_val = 15;
	//Ensure resize value is greater than test value (this is to find errors within the testing values, continue running test)
	EXPECT_TRUE(resize_val > test_val);

	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Add values to the collection
	add_entries(test_val);

	// Ensure values have been collected in the vector
	auto collection_size1 = collection->size();
	ASSERT_FALSE(collection->empty());
	ASSERT_EQ(collection_size1, test_val);

	// Resize the vector to resize_val
	collection->resize(resize_val);

	// The vector should now be of size resize_val and greater than the original size
	ASSERT_EQ(collection->size(), resize_val);
	ASSERT_TRUE(collection->size() > collection_size1);
}

// Verifies resizing decreases the collection
TEST_F(CollectionTest, EnsureResizeDecreasesSize)
{
	const int test_val = 10;
	const int resize_val = 5;
	//Ensure test value is greater than resize value (this is to find errors within the testing values, continue running test)
	EXPECT_TRUE(test_val > resize_val);

	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Add values to the collection
	add_entries(test_val);

	// Ensure values have been collected in the vector
	auto collection_size1 = collection->size();
	ASSERT_FALSE(collection->empty());
	ASSERT_EQ(collection_size1, test_val);

	// Resize the vector to resize_val
	collection->resize(resize_val);

	// The vector should now be of size resize_val and less than the original size
	ASSERT_EQ(collection->size(), resize_val);
	ASSERT_TRUE(collection->size() < collection_size1);
}

// Verifies resizing decreases the collection to zero
TEST_F(CollectionTest, CanResizeToZero)
{
	const int test_val = 10;
	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Add values to the collection
	add_entries(test_val);

	// Ensure values have been collected in the vector
	ASSERT_FALSE(collection->empty());
	ASSERT_EQ(collection->size(), test_val);

	// Resize the vector to 0
	collection->resize(0);

	// The vector should now be empty
	ASSERT_TRUE(collection->empty());
	ASSERT_EQ(collection->size(), 0);
}

// Verifies if a vector can be cleared with the clear() function
TEST_F(CollectionTest, CanClearVector)
{
	const int test_val = 10;
	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Add values to the collection
	add_entries(test_val);

	// Ensure values have been collected in the vector
	ASSERT_FALSE(collection->empty());
	ASSERT_EQ(collection->size(), test_val);

	// Clear the vector
	collection->clear();

	// The vector should now be empty
	ASSERT_TRUE(collection->empty());
	ASSERT_EQ(collection->size(), 0);
}

// Verifies erase(begin,end) erases the collection
TEST_F(CollectionTest, CanEraseVector)
{
	const int test_val = 10;
	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Add values to the collection
	add_entries(test_val);

	// Ensure values have been collected in the vector
	ASSERT_FALSE(collection->empty());
	ASSERT_EQ(collection->size(), test_val);

	// Erase the vector
	collection->erase(collection->begin(), collection->end());

	// The vector should now be empty
	ASSERT_TRUE(collection->empty());
	ASSERT_EQ(collection->size(), 0);
}

// Verifies reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, EnsureReserveDoesNotModifySize)
{
	const unsigned int capacity_increase_val = 10;

	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Is the collection size is currently 0
	auto collection_size1 = collection->size();
	ASSERT_EQ(collection_size1, 0);

	// Find the current capacity
	auto collection_capacity1 = collection->capacity();

	// Use reserve to increase the collection capacity
	collection->reserve(collection_capacity1 + capacity_increase_val);

	// Ensure capacity has increased to the expected value, use EXPECT so that we can also test if the size has changed afterwards
	EXPECT_EQ(collection->capacity(), collection_capacity1 + capacity_increase_val);

	// Ensure size has not changed. This is the last assertion, so ASSERT can be used
	ASSERT_EQ(collection->size(), collection_size1);
}

// Verifies the std::out_of_range exception is thrown when calling at() with an index out of bounds
TEST_F(CollectionTest, CannotAccessOutOfBounds)
{
	const unsigned int index = 100;
	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Is the size of the collection less than the provided index
	ASSERT_TRUE(collection->size() < index);

	// Does the at() method throw a out_of_range when called with an out of bounds index
	ASSERT_THROW(collection->at(index), std::out_of_range);
}

// Verifies that negative index values to at() throw a std::out_of_range exception
// Negative test
TEST_F(CollectionTest, CannotUseNegativeIndex)
{
	const int index = -10;
	// Ensure test value is correct
	EXPECT_TRUE(index < 0);

	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Does the at() method throw a out_of_range when called with a negative index
	ASSERT_THROW(collection->at(index), std::out_of_range);
}

// Verifies that pop_back() decreases size by 1
// Positive test
TEST_F(CollectionTest, EnsurePopBackDecreasesSize)
{
	const int test_val = 10;
	// Does the collection start empty
	ASSERT_TRUE(collection->empty());

	// Add values to the collection
	add_entries(test_val);

	// Ensure values have been collected in the vector
	auto collection_size1 = collection->size();
	ASSERT_FALSE(collection->empty());
	ASSERT_EQ(collection_size1, test_val);

	// Pop the last element
	collection->pop_back();

	// Is the vector now test_val - 1 size
	EXPECT_EQ(collection->size(), test_val - 1);
	// Is the current size less than the original size
	EXPECT_TRUE(collection->size() < collection_size1);
}
